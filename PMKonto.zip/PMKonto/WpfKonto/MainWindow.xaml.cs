﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CLKonto;

namespace WpfKonto
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Konto k;
        AlarmWindow Alarm;

        public MainWindow()
        {
            InitializeComponent();
            k = new Konto();
            Alarm = new AlarmWindow();
            tbName.Text = k.Name;
            tbKonto.Text = Convert.ToString(k.Kontostand);
            k.evKontoLeer += new Konto.delKontoLeer(AlarmWindowTxtBoxAdder);
            k.evKontoLeer += new Konto.delKontoLeer(DisableDecrease);


            k.evKontoVoll += new Konto.delKontoVoll(EnableRaise);
            k.evKontoVoll += new Konto.delKontoVoll(AlarmWindowTxtBoxAdder);
        }
        public void AlarmWindowTxtBoxAdder(object sender, string m)
        {
            
            Alarm.Show();

            Alarm.AlarmTxtBox.Text += m;
            

        }
        public void DisableDecrease(object sender, string m)
        {
            tbAbheben.IsEnabled = false;
            

        }
        public void EnableRaise(object sender, string m)
        {
          if( tbAbheben.IsEnabled == false )
            if (k.Kontostand >= 0)
            {
                tbAbheben.IsEnabled = true;
                

            }

        }
        void k_evKontoLeer(object sender, string e)
        {
            throw new NotImplementedException();
        }
        private void KontoLeerMeldung (object sender, string m)
        {
            //MessageBox.Show(m);

        }
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
        if (tbBetrag.Text != "")
           
                    
        k.decrease(Convert.ToDouble(tbBetrag.Text));
                    
                  

                
                
        tbKonto.Text = Convert.ToString(k.Kontostand);
            
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {   
            if (tbBetrag.Text != "")
            try
            {
                k.raise(Convert.ToDouble(tbBetrag.Text));
            }
            catch
            {
                MessageBox.Show("Ungültige Werte");
            }
            tbKonto.Text = Convert.ToString(k.Kontostand);
        }

        private void tbBetrag_TextChanged(object sender, TextChangedEventArgs e)
        {
        }

        private void tbBetrag_GotFocus(object sender, RoutedEventArgs e)
        {
            tbBetrag.Text = "";
        }


        private void tbMeldung_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void AlarmBtnWinShow_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void tbBetrag_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }
    }
}
