﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CLKonto
{
    public class Konto
    {
        public delegate void delKontoLeer(object sender, string e);
        public event delKontoLeer evKontoLeer;
        public delegate void delKontoVoll(object sender, string a);
        public event delKontoVoll evKontoVoll;

        private string name;

        public string Name
        {
            get { return name; }
        }
        private double kontostand;

        public double Kontostand
        {
            get { return kontostand; }
        }

        public Konto()
        {
            this.name = "Mustermann";
            this.kontostand = 50;
        }

        public Konto(string name, double stand)
        {
            this.kontostand = stand;
            this.name = name;
        }
        public void raise(double value)
        {
            
            if (value > 0)
            this.kontostand = this.kontostand + value;
            if (evKontoVoll != null)
            {
                string msg = "Die Abhebefunktion ist aktiviert\n";

                evKontoVoll(this, msg);
            }
        }
        public void decrease(double value)
        {
            double kontostandcheck = kontostand - value;
            
            if (kontostandcheck < 0)
            {
                

                if (evKontoLeer != null)
                {
                    string msg = ("Konto leer oder im Minus! Abheben wurde deaktivert\n");
                    evKontoLeer(this, msg);

                }

            }
            if (kontostandcheck < 0)
            {
                
            }
            else
            {
                this.kontostand = this.kontostand - value;

            }
                    
                        
            
        }
    }
}
